{
  // Language: English pages live at /, Spanish pages at /es/. The EN/ES buttons go to the matching page.
  const isES = location.pathname.split('/').includes('es');
  const lang = isES ? 'es' : 'en';
  const file = location.pathname.split('/').pop() || 'index.html';
  const go = l => {
    if (l === lang) return;
    try { localStorage.setItem('lao-lang', l); } catch (e) {}
    location.href = l === 'es' ? 'es/' + (file === 'index.html' ? '' : file) : '../' + (file === 'index.html' ? '' : file);
  };
  const en = document.getElementById('l-en'), es = document.getElementById('l-es');
  if (en && es) {
    en.setAttribute('aria-pressed', lang === 'en'); es.setAttribute('aria-pressed', lang === 'es');
    en.addEventListener('click', () => go('en')); es.addEventListener('click', () => go('es'));
  }

  // Quote form: sent to Netlify Forms (lands in the Netlify dashboard and your email notification).
  const EM = {en: 'hello@laosignaturecleaning.com', es: 'hola@laosignaturecleaning.com'};
  const f = document.getElementById('qf');
  if (f) f.addEventListener('submit', async ev => {
    ev.preventDefault();
    const v = id => document.getElementById(id).value.trim();
    const done = document.getElementById('done');
    const say = (en, es) => { done.textContent = lang === 'es' ? es : en; done.classList.add('show'); };
    if (!v('f-name') || !v('f-phone')) return say('Please add your name and phone.', 'Por favor agrega tu nombre y teléfono.');
    const lf = document.getElementById('f-lang'); if (lf) lf.value = lang;
    const btn = f.querySelector('button[type=submit]'); if (btn) btn.disabled = true;
    try {
      const r = await fetch('/', { method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: new URLSearchParams(new FormData(f)).toString() });
      if (!r.ok) throw new Error(r.status);
      f.reset();
      say('Thank you! We received your request and will reply the same business day.', '¡Gracias! Recibimos tu solicitud y te respondemos el mismo día hábil.');
      if (window.gtag) gtag('event', 'generate_lead', {form: 'quote'});
      if (window.fbq) fbq('track', 'Lead');
    } catch (e) {
      say(`We couldn't send it. Please call or WhatsApp (786) 381-0037 or email ${EM.en}.`, `No se pudo enviar. Llámanos o escríbenos por WhatsApp al (786) 381-0037 o escribe a ${EM.es}.`);
    } finally { if (btn) btn.disabled = false; }
  });
}
